// genCase
function genCase(cat) {
  switch (cat) {
    case "paragonStart":
      alert("you are opening:\n\n" + `https://paragon-${sessionStorage.getItem("region")}.amazon.com`);
      return;
    case "cid":
      alert("you are opening:\n\n" + `https://paragon-${sessionStorage.getItem("region")}.amazon.com/hz/view-case?caseId=${globalIdentifierCheck(document.getElementById("caseID").value, "CID")}`);
      return;
    case "sopSearch":
      alert(`you are opening:\n\nhttps://paragon-${sessionStorage.getItem("region")}.amazon.com/hz/dox-search?searchQuery=${globalIdentifierCheck(document.getElementById("sopSearch-value").value, "SOP")}&contentType=SOP&filter=layer%3A${document.getElementById(`sopSearch-mkt-${ifUsEuMeen(sessionStorage.getItem("region"))}`).value}&filter=locale%3Aen-US`);
      return;
    case "fclm":
      alert(`you are opening:\n\nhttps://fclm-portal.amazon.com/employee/activityDetails?employeeId=${globalIdentifierCheck(document.getElementById("fclm").value, "AGT")}`);
      return;
    case "agentWIP":
      alert(`you are opening:\n\nhttps://paragon-${sessionStorage.getItem("region")}.amazon.com/hz/dox-search?searchQuery=owner:${globalIdentifierCheck(document.getElementById("agntWIP").value, "AGT")}&contentType=CASE&filter=status%3Awork-in-progress`);
      return;
    case "andonLaunch":
      let siteAssign = prompt("enter your site:", "CPA");
      if (!siteAssign) {
        alert("please enter your site ID.");
        throw new Error("please enter your site ID.");
      } else {
        alert(`you are opening:\n\nhttps://paragon-${sessionStorage.getItem("region")}.amazon.com/hz/paragon/andoncord/advisor-view?siteName=${siteAssign}`);
      }
      return;
    default:
      throw new Error("undefined");
  }
}

// tixCase
function tixCase(cat) {
  switch (cat) {
    case "quickLink":
      alert(`you are opening:\n\nhttps://paragon-${sessionStorage.getItem("region")}.amazon.com/mn/paragon/diagnostic/show?resourcePath=RemedyQuicklink&region=${sessionStorage.getItem("region")}&quicklink_id=${globalIdentifierCheck(document.getElementById("quickLink").value, "TIX")}`);
      return;
    case "tixLookup":
      alert(`you are opening:\n\nhttps://paragon-${sessionStorage.getItem("region")}.amazon.com/mn/paragon/diagnostic/show?resourcePath=ViewTicket&region=${sessionStorage.getItem("region")}&ticket_id=${globalIdentifierCheck(document.getElementById("tixLookup").value, "TIX")}`);
      return;
    default:
      throw new Error("undefined");
  }
}

// soaCase
function soaCase(cat) {
  switch (cat) {
    case "spotASIN":
      alert(`you are opening:\n\nhttps://paragon-${sessionStorage.getItem("region")}.amazon.com/spot/tools#/asin_troubleshooting/asin_details;asin=${globalIdentifierCheck(document.getElementById("spotASIN-ASIN").value, "ASIN")};caseId=${globalIdentifierCheck(document.getElementById("spotASIN-CID").value, "CID")};marketplaceId=${document.getElementById(`spotASIN-rgn-${ifUsEuMeen(sessionStorage.getItem("region"))}`).value}`);
      return;
    case "spotOID":
      alert(`you are opening:\n\nhttps://paragon-${sessionStorage.getItem("region")}.amazon.com/spot/tools#/order_information;orderId=${globalIdentifierCheck(document.getElementById("spotOID-COID").value, "COID")};caseId=${globalIdentifierCheck(document.getElementById("spotOID-CID").value, "CID")};marketplaceId=${document.getElementById(`spotASIN-rgn-${ifUsEuMeen(sessionStorage.getItem("region"))}`).value}`);
      return;
    case "srpdv":
      alert(`you are opening:\n\nhttps://csi.amazon.com/view?view=simple_product_data_view&item_id=${globalIdentifierCheck(document.getElementById("srpdv-asin").value, "ASIN")}&marketplace_id=${document.getElementById(`srpdv-rgn-${ifUsEuMeen(sessionStorage.getItem("region"))}`).value}&submit=Show`);
      return;
    case "blameO":
      alert(`you are opening:\n\nhttps://csi.amazon.com/view?view=blame_o&item_id=${globalIdentifierCheck(document.getElementById("blameO-ASIN").value, "ASIN")}&marketplace_id=${document.getElementById(`blameO-rgn-${ifUsEuMeen(sessionStorage.getItem("region"))}`).value}&search_string=${blameO_attr(document.getElementById("blameO-attr").value)}&submit=Show`);
      function blameO_attr(attr) { if (!attr) { return ""; } else { return attr; } }
      return;
    case "showGate":
      alert(`you are opening:\n\nhttps://csi.amazon.com/view?view=get_gating_decisions_view&item_id=${globalIdentifierCheck(document.getElementById("showGate-ASIN").value, "ASIN")}&marketplace_id=${document.getElementById(`showGate-rgn-${ifUsEuMeen(sessionStorage.getItem("region"))}`).value}&customer_id=${globalIdentifierCheck(document.getElementById("showGate-MCID").value, "MCID")}&listing_type=purchasable&submit=Show`);
      return;
    case "submHist":
      alert(`you are opening:\n\nhttps://csi.amazon.com/view?view=submission_history&customer_id=${globalIdentifierCheck(document.getElementById("submHist-MCID").value, "MCID")}&marketplace_id=${document.getElementById(`submHist-rgn-${ifUsEuMeen(sessionStorage.getItem("region"))}`).value}&sku=${globalIdentifierCheck(document.getElementById("submHist-SKU").value, "SKU")}&submit=Show`);
      return;
    case "globalsel":
      let rgnUPC = sessionStorage.getItem("region");
      alert(`you are opening:\n\nhttps://paragon-${sessionStorage.getItem("region")}.amazon.com/mn/paragon/diagnostic/show?resourcePath=GlobalSellingSupportPreferences&region=${rgnUPC.toUpperCase()}&merchant_id=${globalIdentifierCheck(document.getElementById("globalsel").value, "MCID")}`);
    default:
      throw new Error("undefined");
  }
}

// fbaCase
function fbaCase(cat) {
  switch (cat) {
    case "ilac":
      alert(`you are opening:\n\nhttps://paragon-${sessionStorage.getItem("region")}.amazon.com/ilac/view-ilac-report?shipmentId=${globalIdentifierCheck(document.getElementById("ilac").value, "POID")}`);
      return;
    case "hitchLook":
      alert(`you are opening:\n\nhttps://paragon-${sessionStorage.getItem("region")}.amazon.com/ilac/fnsku-lookup?fnsku=${globalIdentifierCheck(document.getElementById("hitchLook").value, "FNSKU")}`);
      return;
    case "PIM":
      let rgnUPC = sessionStorage.getItem("region");
      alert(`you are opening:\n\nhttps://prepmanager-${sessionStorage.getItem("intWebType")}.amazon.com/view/${globalIdentifierCheck(document.getElementById("PIM").value, "ASIN")}?region=${rgnUPC.toUpperCase()}`);
      return;
    case "REV":
      alert(`you are opening:\n\nhttps://rev-${sessionStorage.getItem("intWebType")}.aka.amazon.com/RemovalsExecutionViewer/orderDetails?fc=${globalIdentifierCheck(document.getElementById("REV-FC").value, "FCID")}&search=${globalIdentifierCheck(document.getElementById("REV-VRET").value, "VRET")}`);
      return;
    case "rmsLookup":
      alert(`you are opening:\n\nhttps://console-${sessionStorage.getItem("region")}.seller-reimbursement.amazon.dev/rms/view/transaction/${globalIdentifierCheck(document.getElementById("rmsLookup").value, "RMSID")}`);
      return;
    case "MYIQT":
      alert(`you are opening:\n\nhttps://fba-swivt-inventory-console-${sessionStorage.getItem("region")}-${sessionStorage.getItem("intWebType")}.${sessionStorage.getItem("intWebType")}.proxy.amazon.com/MYITroubleShooter/input?fnsku=${globalIdentifierCheck(document.getElementById("MYIQT-fnsku").value, "FNSKU")}&merchantCustomerId=${globalIdentifierCheck(document.getElementById("MYIQT-mcid").value, "MCID")}&marketplaceId=${document.getElementById(`MYIQT-rgn-${ifUsEuMeen(sessionStorage.getItem("region"))}`).value}`);
      return;
    case "SWIVT":
      let swi_fnsku = globalIdentifierCheck(document.getElementById("SWIVT-fnsku").value, "FNSKU"),
        swi_mcid = globalIdentifierCheck(document.getElementById("SWIVT-mcid").value, "MCID"),
        baseUrl = `https://fba-swivt-inventory-console-${sessionStorage.getItem("region")}-${sessionStorage.getItem("intWebType")}.${sessionStorage.getItem("intWebType")}.proxy.amazon.com/Reconciliation/input`;
      alert("please note that this tool will be generating the link first before presenting the link to you. upon clicking OK, please wait 5 seconds for the request to be processed.\n\nyou may close the previous tab once the request has been opened (and reload as needed when results fail to generate).");
      alert(`you are opening:\n\n${baseUrl}?fnsku=${swi_fnsku}&merchantCustomerId=${swi_mcid}&requestId=`);
      setTimeout(() => {
        alert(`you are opening:\n\n${baseUrl}?fnsku=&merchantCustomerId=&requestId=amzn1.fba.reconciliationReport.${swi_mcid}.${swi_fnsku}`);
      }, 5000);
      return;
    case "sidMatch":
      alert(`you are opening:\n\nhttps://paragon-${sessionStorage.getItem("region")}.amazon.com/hz/dox-search?searchQuery=merchantId:${globalIdentifierCheck(document.getElementById("sidMatch-MCID").value, "MCID")}%20AND%20${globalIdentifierCheck(document.getElementById("sidMatch-POID").value, "POID")}`);
      return;
    case "FCR":
      alert(`you are opening:\n\nhttps://fcresearch-${sessionStorage.getItem("region")}.aka.amazon.com/${globalIdentifierCheck(document.getElementById("FCR-FC").value, "FCID")}/results?s=${globalIdentifierCheck(document.getElementById("FCR-fnskuLPN").value, document.getElementById("FCR-TYPE").value)}`);
      return;
    case "GRAVIS":
      alert(`you are opening:\n\nhttps://${sessionStorage.getItem("region")}-cretfc-tools-${sessionStorage.getItem("intWebType")}.${sessionStorage.getItem("intWebType")}.proxy.amazon.com/gravis/${document.getElementById("GRAVIS-TYPE").value}/${globalIdentifierCheck(document.getElementById("GRAVIS-idnt").value, GRAVIS_whatType(document.getElementById("GRAVIS-TYPE").value))}`);
      function GRAVIS_whatType(type) {
        switch (type) {
          case "returnPackage":
            return "COID";
          case "returnUnit":
            return "LPN";
          default:
            throw new Error("undefined");
        }
      }
      return;
    case "serenity":
      alert(`you are opening:\n\nhttps://moonraker-${sessionStorage.getItem("region")}.aka.amazon.com/serenity/index.html?view=search&FulfillmentNetworkSKU=${serenityHaveFNSKU()}${serenityOIDorTRID()}`);
      function serenityHaveFNSKU() {
        if (document.getElementById("serenityHasFNSKU")?.checked) {
          return globalIdentifierCheck(document.getElementById("serenity-FNSKU").value, "FNSKU");
        } else { return ""; }
      }
      function serenityOIDorTRID() {
        switch (document.getElementById("serenity-type").value) {
          case "pthfnd":
            return `&SourceTransactionReferenceID=${globalIdentifierCheck(document.getElementById("serenity-trid").value, "TRID")}`;
          case "nortn":
            return `&OrderID=${globalIdentifierCheck(document.getElementById("serenity-coid").value, "COID")}`;
          default:
            throw new Error("undefined");
        }
      }
      return;
    default:
      throw new Error("undefined");
  }
}

// scCase
function scCase(cat) {
  switch (cat) {
    case "MYI":
      alert(`you are opening:\n\nhttps://${sessionStorage.getItem("scWeb")}.amazon.com/myinventory/inventory?fulfilledBy=all&page=1&pageSize=25&searchField=${document.getElementById("MYI-type").value.toLowerCase()}&searchTerm=${globalIdentifierCheck(document.getElementById("MYI-idnt").value, document.getElementById("MYI-type").value)}`);
      return;
    case "FYP":
      alert(`you are opening:\n\nhttps://${sessionStorage.getItem("scWeb")}.amazon.com/fixyourproducts?${globalIdentifierCheck(document.getElementById("FYP-idnt").value, document.getElementById("FYP-type").value)}`);
      return;
    case "FSI":
      alert(`you are opening:\n\nhttps://${sessionStorage.getItem("scWeb")}.amazon.com/inventoryplanning/stranded-inventory?search=${globalIdentifierCheck(document.getElementById("FSI-idnt").value, document.getElementById("FSI-type").value)}`);
      return;
    case "mngOrd":
      alert(`you are opening:\n\nhttps://${sessionStorage.getItem("scWeb")}.amazon.com/orders-v3/order/${globalIdentifierCheck(document.getElementById("mngOrd").value, "COID")}`);
      return;
    case "mngRet":
      alert(`you are opening:\n\nhttps://${sessionStorage.getItem("scWeb")}.amazon.com/gp/returns/list/v2?searchBy=${document.getElementById("mngRet-type").value}&searchString=${globalIdentifierCheck(document.getElementById("mngRet-idnt").value, "COID")}`);
      return;
    case "rmsRep":
      alert(`you are opening:\n\nhttps://${sessionStorage.getItem("scWeb")}.amazon.com/reportcentral/REIMBURSEMENTS/0/` + encodeURIComponent(`{"filters":["","","${globalIdentifierCheck(document.getElementById("rmsRep-rms").value, "RMSID")}",""],"pageOffset":1,"searchDays":365}`));
      return;
    case "cxShipSales": // TO BE WORKED ON LATER
      alert("you are opening:\n\n" + "https://" + sessionStorage.getItem("scWeb") + ".amazon.com/reportcentral/SHIPMENT_SALES/0/" + encodeURI("{") + '"filters":[' + cxShipIDNT() + '],"pageOffset":1,"searchDays":' + document.getElementById("cxShipSales-time").value + encodeURI("}"));
      function cxShipIDNT() {
        let idnt = document.getElementById("cxShipSales-idnt").value,
          type = document.getElementById("cxShipSales-type").value;
        if (!idnt) {
          let cxShipConf = "this will return all identifiers for this report. are your sure?"
          if (!confirm(cxShipConf)) {
            alert("ASIN, FNSKU, or COID is required.");
            throw new Error("ASIN, FNSKU, or COID is required.");
          } else { return '"","",""'; }
        } else {
          if ((type == "ASIN") || (type == "FNSKU")) {
            switch (type) {
              case "ASIN":
                return '"' + globalIdentifierCheck(idnt, type) + '","",""';
              case "FNSKU":
                return '"","' + globalIdentifierCheck(idnt, type) + '",""';
              default:
                throw new Error("undefined");
            }
          } else {return '"","","' + globalIdentifierCheck(idnt, "COID") + '"'; }
        }
      }
    case "ROid":
      alert(`you are opening:\n\nhttps://${sessionStorage.getItem("scWeb")}.amazon.com/recoveryui/removal-order/detail?sourceRemovalOrderId=${globalIdentifierCheck(document.getElementById("ROid").value, "ROID")}`);
      return;
    case "fbaCustRet":
      switch (document.getElementById("fbaCustRet-type").value) {
        case "idnt":
          const idnnt = document.getElementById("fbaCustRet-idntINP").value;
          const idnntType = document.getElementById("fbaCustRet-idntTYP").value;
          const idnnnt = { asin: 3, sku: 0, fnsku: 2, coid: 1 };
          if (!(idnntType in idnnnt)) { throw new Error("undefined"); }
          const filters = Array(5).fill("");
          filters[idnnnt[idnntType]] = globalIdentifierCheck(idnnt, idnntType.toUpperCase());
          alert("you are opening:\n\n" + `https://${sessionStorage.getItem("scWeb")}.amazon.com/reportcentral/CUSTOMER_RETURNS/0/` + encodeURI(`{"filters":[${filters.map(f => `"${f}"`).join(",")}],"pageOffset":1,"searchDays":365}`));
          return;
        case "lpn":
          alert(`you are opening:\n\nhttps://${sessionStorage.getItem("scWeb")}.amazon.com/reportcentral/CUSTOMER_RETURNS/0/` + encodeURIComponent(`{"filters":["","","","","${lpglobalIdentifierCheck(document.getElementById("fbaCustRet-lpnINP").value, "LPN")}"],"pageOffset":1,"searchDays":365}`));
          return;
        default:
          throw new Error("undefined");
      }
    case "shipm":
      alert(`you are opening:\n\nhttps://${sessionStorage.getItem("scWeb")}.amazon.com/fba/inbound-shipment/summary/${globalIdentifierCheck(document.getElementById("shipm").value, "POID")}`);
      return;
    case "ledger": // TO BE WORKED ON LATER
      let filters = [
        LEDGER_hasIDNT(),
        '"DAILY"',
        '"FC"',
        '"84700"',
        `"${document.getElementById("ledgerContainsTRID").value.replaceAll(" ", "")}"`,
        `"${document.getElementById("ledgerEvt").value}"`,
        LEDGER_isAdjSel(),
        `"${globalIdentifierCheck(document.getElementById("ledgerContainsFC").value, "FCID")}"`,
        `"${document.getElementById("ledgerDisp").value}"`
      ];
      const searchDays = document.getElementById("ledgerTime").value;
      alert(`you are opening:\n\nhttps://${sessionStorage.getItem("scWeb")}.amazon.com/reportcentral/LEDGER_REPORT/0/` + encodeURIComponent(`{"filters":[${filters.join(",")}],"pageOffset":1,"searchDays":${searchDays}}`));
      function LEDGER_hasIDNT() {
        if (!document.getElementById("ledgerHasASIN")?.checked && !document.getElementById("ledgerHasSKU")?.checked && !document.getElementById("ledgerHasFNSKU")?.checked) {
          let confirmIdnt = "this will return all identifiers for this report. are your sure?";
          if (!confirm(confirmIdnt)) {
            alert("ASIN, SKU, or FNSKU is required.");
            throw new Error("ASIN, SKU, or FNSKU is required.");
          } else { return '"","",""'; }
        } else {
          return '"' + checkIDNT("ASIN") + '","' + checkIDNT("SKU") + '","' + checkIDNT("FNSKU") + '"';
          function checkIDNT(idnt) {
            if (document.getElementById("ledgerHas" + idnt)?.checked) {
              return globalIdentifierCheck(document.getElementById("ledgerContains" + idnt).value, idnt);
            } else { return ""; }
          }
        }
      }
      function LEDGER_isAdjSel() {
        if (document.getElementById("ledgerEvt").value == "Adjustments") {
          if (!document.getElementById("adjDamaged")?.checked && !document.getElementById("adjDestroyed")?.checked && !document.getElementById("adjFound")?.checked && !document.getElementById("adjLost")?.checked && !document.getElementById("adjOther")?.checked) {
            alert("please select at least one adjustment reason group.");
            throw new Error("please select at least one adjustment reason group.");
          } else {
            let adjVars = new Array();
            if (document.getElementById("adjDamaged")?.checked) { adjVars.push('"Damaged"'); }
            if (document.getElementById("adjDestroyed")?.checked) { adjVars.push('"Destroyed"'); }
            if (document.getElementById("adjFound")?.checked) { adjVars.push('"Found"'); }
            if (document.getElementById("adjLost")?.checked) { adjVars.push('"Lost"'); }
            if (document.getElementById("adjOther")?.checked) { adjVars.push('"Other"'); }
            return "[" + adjVars.toString() + "]";
          }
        } else { return '""'; }
      }
      return;
    case "helpRes":
      alert(`you are opening:\n\nhttps://${sessionStorage.getItem("scWeb")}.amazon.com/${helpPageOrSellerUni()}${globalIdentifierCheck(document.getElementById("helpRes-query").value, "HELP")}`);
      function helpPageOrSellerUni() {
        switch (document.getElementById("helpRes-type").value) {
          case "helpPage":
            return "help/hub/reference/search?query=";
          case "sellerUni":
            return "learn/s?searchText=";
          default:
            throw new Error("undefined");
        }
      }
      return;
    default:
      throw new Error("undefined");
  }
}